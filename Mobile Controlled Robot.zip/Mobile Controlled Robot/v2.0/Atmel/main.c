/*
 * Atmel.c
 *
 * Created: 11/13/2023 3:42:02 AM
 * Author : Robert
 */ 

#define F_CPU 8000000UL

#define MOTOR_DRIVER_PORT PORTC

//LCD
#define LCD_DATA_PORT PORTA
#define LCD_CTRL_PORT PORTB
#define RS_PIN PINB2 //data bus to be treated as command
#define RW_PIN PINB1//set to read mode
#define E_PIN PINB0

#define FUNCTION_RESET 0x38
#define LCD_CLEAR 0b00000001
#define LCD_HOME 0b00000010
#define LCD_DISPLAY_ON_CURSOR_OFF 0b00001100
#define LCD_ENTRY_MODE 0b00000110

//for USART
#define BAUDRATE 9600
#define BAUD_PRESCALLER (((F_CPU / (BAUDRATE * 16UL))) - 1)

#include <avr/io.h>
#include <util/delay.h>

//--------------------------USART---------------------
void USART_init(void){
	/* Set baud rate */
	UBRRH = (uint8_t)(BAUD_PRESCALLER>>8);
	UBRRL = (uint8_t)(BAUD_PRESCALLER);
	/* Enable receiver and transmitter */
	UCSRB = (1<<RXEN)|(1<<TXEN);
	/* Set frame format: */
	UCSRC = (1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0); //8 bit data
}

void USART_transmit(unsigned char data){
	while (!(UCSRA & (1 << UDRE)));
	UDR = data;
}

unsigned char USART_receive(void){
	while(!(UCSRA & (1<<RXC)));
	return UDR;
}

void UART_received_string(char* buffer, int bufferSize){
	int i=0;
	
	while(i < bufferSize - 1){
		char receivedChar = USART_receive();
		if(receivedChar == '\n' || receivedChar == '\r'){
			break;
		}
		buffer[i++] = receivedChar;
	}
	buffer[i] = '\0';
}

void USART_transmition_string(const char* command){
	while(*command != '\0'){
		USART_transmit(*command);
		command++;
	}
	USART_transmit('\r');
	USART_transmit('\n');
	_delay_ms(1000);
}
//--------------------------USART---------------------

//-------------------------------LCD----------------------------------------------------

//when in command mode
void LCD_command(unsigned char command){
	LCD_DATA_PORT = command;
	LCD_CTRL_PORT &= ~(1<<RS_PIN);//RS 0(command mode)
	LCD_CTRL_PORT&=~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//CLEAR SCREEN
void Lcd_clear_screen(void){
	LCD_command(LCD_CLEAR);
	_delay_ms(2);
}

//initialize LCD
void LCD_init(){
	_delay_ms(15);
	LCD_command(FUNCTION_RESET);
	_delay_ms(5);
	LCD_command(FUNCTION_RESET);
	_delay_ms(120);
	LCD_command(FUNCTION_RESET);
	LCD_command(FUNCTION_RESET);
	LCD_command(LCD_DISPLAY_ON_CURSOR_OFF);
	LCD_command(LCD_CLEAR);
	_delay_ms(2);
	LCD_command(LCD_ENTRY_MODE);
	_delay_ms(5);
}

//when in data mode
void LCD_data(unsigned char data){
	LCD_DATA_PORT = data;
	LCD_CTRL_PORT |= (1<<RS_PIN);//RS 1(character data mode)
	LCD_CTRL_PORT &= ~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//passing string
void LCD_string(char *str){
	int a = 1;
	while(*str){
		LCD_data(*str++);
		_delay_ms(2);
		//LCD_command(0b00011100);//display shift right
		//_delay_ms(1);
		if(a==16){
			LCD_command(0xC0);
			_delay_ms(2);
			
		}
		if(a==32){
			a=1;
			LCD_command(LCD_CLEAR);
			_delay_ms(2);
		}
		a++;
	}
	//LCD_command(0b00011000); //left shift
	//_delay_ms(1);
	
}
//-------------------------------LCD----------------------------------------------------

void Left_wheel_forward(void){
	PORTC |= (1<<PINC0);
	PORTC &= ~(1<< PINC1);
}

void right_wheel_forward(void){
	PORTC |= (1<<PINC2);
	PORTC &= ~(1<< PINC3);
}


void Left_wheel_reverse(void){
	PORTC &= ~(1<<PINC0);
	PORTC |= (1<< PINC1);
}


void right_wheel_reverse(void){
	PORTC &= ~(1<<PINC2);
	PORTC |= (1<< PINC3);
}

void Left_wheel_stop(void){
	PORTC |= (1<<PINC0);
	PORTC |= (1<< PINC1);
}

void right_wheel_stop(void){
	PORTC |= (1<<PINC2);
	PORTC |= (1<< PINC3);
}

void stop(void){
	PORTC |= (1<<PINC0);
	PORTC |= (1<< PINC1);
	PORTC |= (1<<PINC2);
	PORTC |= (1<< PINC3);
}
void RobotLogic(char res){
	Lcd_clear_screen();
	switch (res)
	{
		case '7':
		LCD_string("L Forward");
		USART_transmition_string("L Forward");
		Left_wheel_forward();
		break;
		case '1':
		LCD_string("L Reverse");
		USART_transmition_string("L Reverse");
		Left_wheel_reverse();
		break;
		case '9':
		LCD_string("RF");
		USART_transmition_string("RF");
		right_wheel_forward();
		break;
		case '3':
		LCD_string("RR");
		USART_transmition_string("RR");
		right_wheel_reverse();
		break;
		case '4':
		LCD_string("LS");
		USART_transmition_string("LS");
		Left_wheel_stop();
		break;
		case '6':
		LCD_string("RS");
		USART_transmition_string("RS");
		right_wheel_stop();
		break;
		default:
		LCD_string("STOP");
		USART_transmition_string("STOP");
		stop();
		break;
	}
}

//-------INDICATORS-------------------
void robot_status(int i){
	if(i == 1){
		PORTB |= (1<< PINB3);
	}else{
		PORTB &= ~(1<< PINB3);
	}
}

void indicates_transmission(void){
	PORTD |= (1<< PIND3);
	_delay_ms(300);
	PORTD &= ~(1 << PIND3);
}

int main(void)
{
	
	DDRC = 0XFF; //Motor drive
	DDRA = 0xFF; //DATA bus
	DDRB = 0xFF; //control bus
	
	//set output for PIND3
	DDRD = 0b00001000;
	
	//initiallly robot indicates off
	robot_status(0);
	
	//initializing LCD
	LCD_init();
	
	LCD_string("START");
	
	//initializing USART
	USART_init();
	//transmitting String
	USART_transmition_string("Ready?");
	
	//indicate robot to be ON
	robot_status(1);
	
	
    while (1) 
    {
		//receiving characters
		char response = USART_receive();
		//indicating transmission 
		indicates_transmission();
		
		RobotLogic(response);
			
    }
	robot_status(0);
}

