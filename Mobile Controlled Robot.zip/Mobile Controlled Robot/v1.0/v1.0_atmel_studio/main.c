/*
 * v1.0_atmel_studio.c
 *
 * Created: 11/11/2023 4:52:10 AM
 * Author : Robert
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/sfr_defs.h>

void stop();
void left();
void reverse_left();
void stop_left();
void right();
void reverse_right();
void stop_right();

int main(void)
{
	DDRA=0b00001111;
	DDRB=0b00000000;
	PORTA=0b00000000;
	PORTB=0b00000000;
	
    while (1) 
    {
		if(bit_is_clear(PINB,0) && bit_is_clear(PINB,1) &&  bit_is_clear(PINB,2) && bit_is_clear(PINB,3)){
			stop();
		}
		
		//for left 
		if(bit_is_set(PINB,0) && bit_is_clear(PINB,1)){
			left();
		}
		if(bit_is_clear(PINB,0)&&bit_is_set(PINB,1)){
			reverse_left();
		}
		if(( bit_is_clear(PINB,0)&&bit_is_clear(PINB,1) ) || ( bit_is_set(PINB,0)&&bit_is_set(PINB,1) )){
			stop_left();
		}

		//for right
		if(bit_is_set(PINB,2) && bit_is_clear(PINB,3)){
			right();
		}
		if(bit_is_clear(PINB,2) && bit_is_set(PINB,3)){
			reverse_right();
		}
		if(( bit_is_clear(PINB,2)&&bit_is_clear(PINB,3) ) || ( bit_is_set(PINB,2)&&bit_is_set(PINB,3) )){
			stop_right();
		}
    }
}

void stop(void){
	PORTA&=~(1<<PINA0);
	PORTA&=~(1<<PINA1);
	PORTA&=~(1<<PINA2);
	PORTA&=~(1<<PINA3);
}

void left(void){
	PORTA|=(1<<PINA0);
	PORTA&=~(1<<PINA1);
}

void reverse_left(void){
	PORTA&=~(1<<PINA0);
	PORTA|=(1<<PINA1);
}

void stop_left(void){
	PORTA&=~(1<<PINA0);
	PORTA&=~(1<<PINA1);
}

void right(void){
	PORTA|=(1<<PINA2);
	PORTA&=~(1<<PINA3);
}

void reverse_right(void){
	PORTA&=~(1<<PINA2);
	PORTA|=(1<<PINA3);
}
void stop_right(void){
	PORTA&=~(1<<PINA2);
	PORTA&=~(1<<PINA3);
}