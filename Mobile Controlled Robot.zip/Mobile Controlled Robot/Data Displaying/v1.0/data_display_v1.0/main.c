/*
 * data_display_v1.0.c
 *
 * Created: 11/11/2023 12:20:42 PM
 * Author : Robert
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util//delay.h>

#define LCD_DATA_PORT PORTB
#define LCD_CTRL_PORT PORTA
#define RS_PIN PINA0 //data bus to be treated as command
#define RW_PIN PINA1//set to read mode
#define E_PIN PINA2

#define FUNCTION_RESET 0x38
#define LCD_CLEAR 0b00000001
#define LCD_HOME 0b00000010
#define LCD_DISPLAY_ON_CURSOR_OFF 0b00001100
#define LCD_ENTRY_MODE 0b00000110

//when in command mode
void LCD_command(unsigned char command){
	LCD_DATA_PORT = command;
	LCD_CTRL_PORT &= ~(1<<RS_PIN);//RS 0(command mode)
	LCD_CTRL_PORT&=~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//initialize LCD
void LCD_init(){
	_delay_ms(15);
	LCD_command(FUNCTION_RESET);
	_delay_ms(5);
	LCD_command(FUNCTION_RESET);
	_delay_ms(120);
	LCD_command(FUNCTION_RESET);
	//_delay_ms(1);
	LCD_command(FUNCTION_RESET);
	
	
	LCD_command(LCD_DISPLAY_ON_CURSOR_OFF);
	LCD_command(LCD_CLEAR);
	_delay_ms(2);
	LCD_command(LCD_ENTRY_MODE);
	_delay_ms(5);
/*	
LCD_command(0x08);
LCD_command(0x01);
_delay_ms(5);
LCD_command(0x06);
LCD_command(0x02);
_delay_ms(5);
LCD_command(0x0F);
LCD_command(0x80);
	*/
	
}


//when in data mode
void LCD_data(unsigned char data){
	LCD_DATA_PORT = data;
	LCD_CTRL_PORT |= (1<<RS_PIN);//RS 1(character data mode)
	LCD_CTRL_PORT &= ~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//passing string
void LCD_string(char *str){
	int a = 1;
	while(*str){
		LCD_data(*str++);
		if(a>15){
			if(a%40==0){
				LCD_command(0x80);
				_delay_ms(1);
			}
			_delay_ms(100);
			LCD_command(0b00011100);//display shift right
			_delay_ms(1);
		}
		
		a++;
	}
	LCD_command(0b00011000); //left shift
	_delay_ms(1);
	
}

int main(void)
{
    DDRA = 0b11111111;
	DDRB = 0b11111111;
	
	LCD_init();
	
    while (1) 
    {
		LCD_command(LCD_CLEAR);
		_delay_ms(2);
		
		PORTA|=(1<<PINA3);
		LCD_string("Hello Everyone, This is Tushar. It's nice that you've come across this and watching this. Thank you so much");
		_delay_ms(2000);
    }
}

