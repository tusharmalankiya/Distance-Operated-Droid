
#define F_CPU 8000000UL

#include <avr/io.h>
#include <util//delay.h>


#define BAUDRATE 9600
#define BAUD_PRESCALLER (((F_CPU / (BAUDRATE * 16UL))) - 1)

void USART_init(void){
	/* Set baud rate */
	UBRRH = (uint8_t)(BAUD_PRESCALLER>>8);
	UBRRL = (uint8_t)(BAUD_PRESCALLER);
	/* Enable receiver and transmitter */
	UCSRB = (1<<RXEN)|(1<<TXEN);
	/* Set frame format: */
	UCSRC = (1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0); //8 bit data
}

//this function works fine
void USART_transmit(unsigned char data){
	while (!(UCSRA & (1 << UDRE)));
	UDR = data;
}

unsigned char USART_receive(void){
	while(!(UCSRA & (1<<RXC)));
	return UDR;
}

void sendATcommand(const char* command){
	while(*command != '\0'){
		USART_transmit(*command);
		command++;
	}
	USART_transmit('\n');
	USART_transmit('\r');
}



int main(void)
{
	
	USART_init();
	
	//sendATcommand("AT2");
	//USART_transmit('A');
	_delay_ms(100);
	
	
	
	
	while (1)
	{
		unsigned char response = USART_receive();
		
		if(response=='1'){
			sendATcommand("5");
		}
		
		//LCD_string("Hello Everyone, This is Tushar. It's nice that you've come across this and watching this. Thank you so much");
		//_delay_ms(2000);
		
		//char receivedData = USART_receive();
		_delay_ms(200);
	}
	return 0;
}