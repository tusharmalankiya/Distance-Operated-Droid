
/*
 * data_display_v1.0.c
 *
 * Created: 11/11/2023 12:20:42 PM
 * Author : Robert
 */ 

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util//delay.h>

#define LCD_DATA_PORT PORTB
#define LCD_CTRL_PORT PORTA
#define RS_PIN PINA0 //data bus to be treated as command
#define RW_PIN PINA1//set to read mode
#define E_PIN PINA2

#define FUNCTION_RESET 0x38
#define LCD_CLEAR 0b00000001
#define LCD_HOME 0b00000010
#define LCD_DISPLAY_ON_CURSOR_OFF 0b00001100
#define LCD_ENTRY_MODE 0b00000110

#define BAUDRATE 9600
#define BAUD_PRESCALLER (((F_CPU / (BAUDRATE * 16UL))) - 1)
//when in command mode
void LCD_command(unsigned char command){
	LCD_DATA_PORT = command;
	LCD_CTRL_PORT &= ~(1<<RS_PIN);//RS 0(command mode)
	LCD_CTRL_PORT&=~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//initialize LCD
void LCD_init(){
	_delay_ms(15);
	LCD_command(FUNCTION_RESET);
	_delay_ms(5);
	LCD_command(FUNCTION_RESET);
	_delay_ms(120);
	LCD_command(FUNCTION_RESET);
	//_delay_ms(1);
	LCD_command(FUNCTION_RESET);
	
	
	LCD_command(LCD_DISPLAY_ON_CURSOR_OFF);
	LCD_command(LCD_CLEAR);
	_delay_ms(2);
	LCD_command(LCD_ENTRY_MODE);
	_delay_ms(5);
/*	
LCD_command(0x08);
LCD_command(0x01);
_delay_ms(5);
LCD_command(0x06);
LCD_command(0x02);
_delay_ms(5);
LCD_command(0x0F);
LCD_command(0x80);
	*/
	
}


//when in data mode
void LCD_data(unsigned char data){
	LCD_DATA_PORT = data;
	LCD_CTRL_PORT |= (1<<RS_PIN);//RS 1(character data mode)
	LCD_CTRL_PORT &= ~(1<<RW_PIN);//RW 0 (write mode)
	LCD_CTRL_PORT |= (1<<E_PIN); //enable high
	_delay_ms(1);
	LCD_CTRL_PORT &= ~(1<< E_PIN); //enable low
	_delay_ms(1);
	
}

//passing string
void LCD_string(char *str){
	int a = 1;
	while(*str){
		LCD_data(*str++);
		_delay_ms(2);
		//LCD_command(0b00011100);//display shift right
		//_delay_ms(1);
		if(a==16){
			LCD_command(0xC0);
			_delay_ms(1);
				
		}
		if(a==32){
			a=1;
			LCD_command(LCD_CLEAR);
			_delay_ms(2);
		}
		a++;
	}
	//LCD_command(0b00011000); //left shift
	//_delay_ms(1);
	
}


//------------------------------------------------------------UART----------------------------------------------------------
void USART_init(void){
	/* Set baud rate */
	 UBRRH = (uint8_t)(BAUD_PRESCALLER>>8);
	 UBRRL = (uint8_t)(BAUD_PRESCALLER);
	/* Enable receiver and transmitter */
	UCSRB = (1<<RXEN)|(1<<TXEN);
	/* Set frame format: */
	UCSRC = (1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0); //8 bit data
}

//this function works fine
void USART_transmit(unsigned char data){
	while (!(UCSRA & (1 << UDRE)));
	UDR = data;
}

unsigned char USART_receive(void){
	//int timeout = 10000;
	while(!(UCSRA & (1<<RXC))){
		/*if(--timeout == 0){
			return 0;
		}	*/
	}
	return UDR;
}

void UART_received_string(char* buffer, int bufferSize){
	int i=0;
	
	while(i < bufferSize - 1){
		char receivedChar = USART_receive();
		if(receivedChar == '\n' || receivedChar == '\r'){
			break;
		}
		buffer[i++] = receivedChar;
	}
	buffer[i] = '\0';
}

void sendATcommand(const char* command){
	while(*command != '\0'){
		USART_transmit(*command);
		command++;
	}
	//USART_transmit('\r');
	//USART_transmit('\n');
}

int main(void)
{
    DDRA = 0b11111111;
	DDRB = 0b11111111;
	DDRC = 0xFF;
	PORTC = 0x00;
	PORTC &= ~(1<<PINC1);
	//DDRD |= (1<<PIND1);
	//DDRD &= ~(1<<PIND0);
	
	LCD_init();
	USART_init();
	
	sendATcommand("AT\r\n");
	_delay_ms(1000);
	
	LCD_string("AT command sent");
	_delay_ms(2);
	
    while (1) 
    {
		
		PORTA &= ~(1<<PINA3);
		char response[20];
		UART_received_string(response, sizeof(response));
		
		
		LCD_command(LCD_CLEAR);
		_delay_ms(2);
		LCD_string("received");
		_delay_ms(2);
		
		
		LCD_command(LCD_CLEAR);
		_delay_ms(2);
				
		
		
		PORTA|=(1<<PINA3);
		
		if(response[0] == '1'){
			PORTC |= (1<<PINC0);
			LCD_string("ON");
		}else{
			PORTC &= ~(1<<PINC0);
			LCD_string("OFF");
		}
		
		
		/*if(response == "OK"){
			LCD_command(LCD_CLEAR);
			_delay_ms(2);
			LCD_string(response);
			//return 0;
		}else{
			LCD_command(LCD_CLEAR);
			_delay_ms(2);
			LCD_string(response);
		}*/
		
		//LCD_string("Hello Everyone, This is Tushar. It's nice that you've come across this and watching this. Thank you so much");
		//_delay_ms(2000);
		
		//char receivedData = USART_receive();
		_delay_ms(200);
    }
	return 0;
}



